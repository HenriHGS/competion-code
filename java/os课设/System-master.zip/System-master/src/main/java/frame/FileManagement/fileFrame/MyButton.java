package frame.FileManagement.fileFrame;

import javax.swing.*;

public class MyButton extends JButton {
    int number;
    public MyButton(String s,Icon icon,int num){
        super(s,icon);
        number=num;
    }
}
