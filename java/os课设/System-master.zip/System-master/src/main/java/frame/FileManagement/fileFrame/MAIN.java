package frame.FileManagement.fileFrame;

import javax.swing.*;

public class MAIN {
    public static void main(String[] args) throws Exception {
        new ViewInitialization();
    }
}
